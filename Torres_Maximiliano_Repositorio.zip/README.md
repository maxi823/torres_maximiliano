# Curso de programación full stack

## MÓDULO 2 - Repositorio y WorkFlow

**Autor:** Maximiliano Torres

**Descripción:** Este repositorio fue creado con fines académicos por lo que en el futuro cercano será eliminado.
